SafeChat Lab - cross-session harassment dataset export
messages.csv   one row per chat message. sender/target are study codes (P001 = human, B001 = bot).
               target = who the message was aimed at, resolved by the engine (reply > @mention > name > room owner);
               target_method says which. from_bank = message-bank bucket if the participant used a suggested message.
               T, p_threat = content model output; risk, tier = engine output at that moment.
               ts = real wall-clock time; engine_ts = lab-clock time the engine used (each session is
               mapped SAFECHAT_DAYS_PER_SESSION days after the previous one).
pairs.csv      every observed (sender, target) pair. label 1 = repeat harassment. label_source = manual annotation
               or role_assignment (a harasser/subtle_harasser/escalator role aimed at that target).
participants.csv  roles only - display names are never exported.
sessions.csv   chat sessions (one live stream = one session).
Evaluate with:  python scripts/evaluate_collected.py --export <this zip>
